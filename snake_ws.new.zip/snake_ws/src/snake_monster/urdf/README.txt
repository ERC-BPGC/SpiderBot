The convention we use is that the xacro module macros automatically define a
couple of specifically named subelements:
* (name)|INPUT_INTERFACE is the input body of a module
* (name)|OUTPUT_INTERFACE is the output joint of a module
